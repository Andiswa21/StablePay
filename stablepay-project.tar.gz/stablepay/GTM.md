# Go-to-market: StablePay

## The customer (name them before the demo)

Start with one real spaza or tuck shop in a township you can visit (for example Khayelitsha, Soweto or
Alexandra). The shop owner takes cash today and sometimes mobile money. Before the demo, confirm with the
owner:

- How many sales a day, and average basket size (the demo uses R85 for convenience; replace it with theirs).
- Whether customers already have wallets, mobile money, or a bank app that can scan a QR code.
- What it costs them to bank cash today (transport, time, risk), and what card or mobile-money fees they pay.
- Who restocks, and how: cash-and-carry, wholesaler, or a bank transfer.

The name in the Figma prototype ("Mam Nomsa's Spaza Shop") is a placeholder. Replace it with the real owner
and their agreement before you present a pitch.

## Who pays, and why they would switch

| Segment | Pain today | What StablePay gives them | Priority |
|---|---|---|---|
| Spaza and tuck shops | Cash risk, slow banking, card-machine fees | QR or NFC checkout on a phone they own, cash-out to ZAR | First pilot |
| Cash-and-carry and wholesalers | Chasing payments, credit risk | Stablecoin payments in, paid-on-delivery with receipts | Second |
| EV charging and smart-meter operators | Per-kWh payments without accounts | x402 per-use payments with operator-set caps and kill switch | Machine track |
| AI agents and API sellers | No sign-up, no keys, per-call billing | x402 or MPP paywalls | Later |

## Pricing (illustrative until validated)

- Shopkeeper: no hardware cost, no monthly fee in the pilot. Cash-out fee shown per transaction.
- Target cash-out fee: below the card-machine comparison in the prototype (0.5% vs 3.5%). Validate against
  the off-ramp partner's real fees before quoting it to anyone.
- Machine operators: per-transaction fee on x402 payments, or a monthly fee per device.

## Pilot plan (first 90 days)

**Days 1 to 30: prove it with one shop.**
- Recruit one spaza shop. Install the till on the owner's phone. Run R85-style sales for two weeks on
  testnet, then a small mainnet or on-ramp test with the owner's money.
- Measure: sales taken via QR, time from charge to PAID, unmatched transfers, and customer drop-off.

**Days 31 to 60: add cash-out and a second site.**
- Sign an off-ramp partner for ZAR payouts (bank or mobile money). Set limits and KYC with them.
- Onboard 4 to 5 shops in one neighbourhood. Put an NFC sticker on each till.

**Days 61 to 90: decide.**
- Go or no-go on the metrics below. If go, start a wholesaler or charging-station pilot.

## Metrics that decide the next step

- Share of sales taken via stablecoin (target set with each shop before launch)
- Median time from charge to PAID (target under 10 seconds, per the workshop brief)
- Unmatched or late payments per 100 sales
- Cash-out completed within one business day
- Shop owner repeat use: sales per week in week 4 vs week 1

## Channels

- Direct visits to township shops, with a demo on the owner's phone.
- Township and taxi-rank associations, and neighbourhood trader groups.
- Cash-and-carry depots (a fixed location where many shops buy stock).
- Charging-station operators for the machine track.

## Risks and what to do about them

- **Regulation.** Crypto-asset and payment rules in South Africa (FSCA, SARB, FIC) apply to on- and off-ramps.
  Use a licensed partner for cash-out and get legal advice before taking real money.
- **Cash-out cost and limits.** Limits, KYC and fees vary by country. Keep the first pilot inside the partner's
  limits and show the fee on every payout.
- **Gas and wallet friction.** Most shoppers do not have a stablecoin wallet. Start with customers who already
  have one, and use a gas-sponsored flow before asking shoppers to buy gas.
- **Connectivity.** Sales can be queued offline, but settlement needs a connection. Show the queued state clearly.
- **Trust.** Shops will not adopt a system they cannot explain. Keep the owner view simple: what was paid, for
  what, and its status.

## What judges will want to see

- A named customer, with their current payment habits and a pilot agreement or letter of intent.
- Honest fees compared with cash, card machines and mobile money.
- A path to cash-out and a first pilot, with dates.
