// Thin wrapper around the Express API. The Vite dev server proxies /api to port 3001.
export async function api(path, { method = 'GET', body, pin } = {}) {
  const res = await fetch(`/api${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(pin ? { 'X-Operator-Pin': pin } : {})
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

export const isFinal = status => ['paid', 'paid_late', 'expired', 'refunded'].includes(status);
