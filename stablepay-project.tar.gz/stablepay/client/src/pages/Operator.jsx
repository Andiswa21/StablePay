import { useEffect, useState } from 'react';
import { api } from '../api.js';

// Operator view: what was paid, for what, status, unmatched transfers, cash-out, device caps, refunds.
export default function Operator() {
  const [pin, setPin] = useState(sessionStorage.getItem('pin') || '');
  const [unlocked, setUnlocked] = useState(false);
  const [data, setData] = useState({ orders: [], transfers: [], payouts: [], devices: [] });
  const [msg, setMsg] = useState('');
  const [dev, setDev] = useState({ deviceId: 'CHG-12', wallet: '', capUsdc: '5', windowHours: '24' });
  const [cashOut, setCashOut] = useState('');

  async function refresh(p = pin) {
    try {
      const [orders, transfers, payouts, devices] = await Promise.all([
        api('/orders', { pin: p }), api('/transfers', { pin: p }),
        api('/payouts', { pin: p }), api('/devices', { pin: p })
      ]);
      setData({ orders, transfers, payouts, devices });
      setUnlocked(true);
      sessionStorage.setItem('pin', p);
    } catch (e) { setMsg(e.message); setUnlocked(false); }
  }

  useEffect(() => {
    if (!unlocked) return;
    const t = setInterval(() => refresh(), 4000);
    return () => clearInterval(t);
  }, [unlocked, pin]);

  useEffect(() => { if (pin) refresh(pin); }, []);

  const act = async (fn, ok) => {
    try { await fn(); setMsg(ok); await refresh(); } catch (e) { setMsg(e.message); }
  };

  if (!unlocked) {
    return (
      <main className="card narrow">
        <h1>Operator</h1>
        <label>Operator PIN
          <input type="password" value={pin} onChange={e => setPin(e.target.value)} />
        </label>
        <button className="btn primary" onClick={() => refresh(pin)}>Open</button>
        {msg && <p className="err">{msg}</p>}
      </main>
    );
  }

  const settled = data.orders.filter(o => ['paid', 'paid_late'].includes(o.status));
  const available = settled.reduce((a, o) => a + Number(o.usdc), 0) - data.payouts.reduce((a, p) => a + p.usdc, 0);

  return (
    <main className="ops">
      {msg && <p className="notice" onClick={() => setMsg('')}>{msg}</p>}

      <section className="card">
        <h2>Orders</h2>
        <table>
          <thead><tr><th>Order</th><th>For</th><th>ZAR</th><th>USDC</th><th>Status</th><th>Tx</th><th></th></tr></thead>
          <tbody>
            {data.orders.map(o => (
              <tr key={o.id}>
                <td>{o.id}</td><td>{o.label || '—'}</td><td>R{o.amountZar.toFixed(2)}</td><td>{o.usdc}</td>
                <td><span className={`tag ${o.status}`}>{o.status}</span></td>
                <td>{o.explorer ? <a href={o.explorer} target="_blank" rel="noreferrer">view</a> : '—'}</td>
                <td>{o.status === 'paid' || o.status === 'paid_late'
                  ? <button className="btn small danger" onClick={() => act(() => api(`/orders/${o.id}/refund`, { method: 'POST', pin }), 'Refund sent')}>Refund</button>
                  : null}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="card">
        <h2>Unmatched transfers</h2>
        <p className="note">Payments to the shop that did not match an open order (wrong amount or too late). Check and refund by hand.</p>
        {data.transfers.length === 0 ? <p className="note">None.</p> : (
          <ul>{data.transfers.map(t => (
            <li key={t.key}>{(Number(t.amountMicro) / 1e6).toFixed(6)} USDC from {t.payer.slice(0, 8)}… · <a href={`https://sepolia.basescan.org/tx/${t.txHash}`} target="_blank" rel="noreferrer">tx</a></li>
          ))}</ul>
        )}
      </section>

      <section className="card">
        <h2>Cash-out</h2>
        <p className="note">Available: <strong>{available.toFixed(6)} USDC</strong> · 0.5% fee · settles through a partner (mocked here)</p>
        <div className="row">
          <input placeholder="USDC amount" value={cashOut} onChange={e => setCashOut(e.target.value)} />
          <button className="btn primary" onClick={() => act(() => api('/payouts', { method: 'POST', pin, body: { amountUsdc: Number(cashOut) } }), 'Cash-out submitted (mock)')}>Cash out</button>
        </div>
        <ul>{data.payouts.map(p => <li key={p.id}>{p.id}: {p.usdc} USDC → net {p.netUsdc} · {p.reference} · {p.status}</li>)}</ul>
      </section>

      <section className="card">
        <h2>Machine devices and caps</h2>
        <p className="note">Caps are set here by the operator. The device cannot change them.</p>
        <div className="grid">
          <input placeholder="deviceId" value={dev.deviceId} onChange={e => setDev({ ...dev, deviceId: e.target.value })} />
          <input placeholder="wallet 0x…" value={dev.wallet} onChange={e => setDev({ ...dev, wallet: e.target.value })} />
          <input placeholder="cap USDC" value={dev.capUsdc} onChange={e => setDev({ ...dev, capUsdc: e.target.value })} />
          <input placeholder="window hours" value={dev.windowHours} onChange={e => setDev({ ...dev, windowHours: e.target.value })} />
          <button className="btn primary" onClick={() => act(() => api('/devices', { method: 'POST', pin, body: dev }), 'Device registered')}>Register device</button>
        </div>
        <table>
          <thead><tr><th>Device</th><th>Cap</th><th>Spent in window</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {data.devices.map(d => (
              <tr key={d.deviceId}>
                <td>{d.deviceId}</td><td>{d.capUsdc} USDC / {d.windowHours}h</td><td>{d.spentInWindow}</td>
                <td>{d.revoked ? 'revoked' : 'active'}</td>
                <td>{!d.revoked && <button className="btn small danger" onClick={() => act(() => api(`/devices/${d.deviceId}/revoke`, { method: 'POST', pin }), 'Device revoked')}>Revoke</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </main>
  );
}
