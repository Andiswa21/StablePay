import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { api, isFinal } from '../api.js';

// Customer page: the same payment request, opened from a link or a sticker.
export default function Pay() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try { const o = await api(`/orders/${id}`); if (alive) setOrder(o); }
      catch (e) { if (alive) setError(e.message); }
    };
    load();
    const t = setInterval(() => { if (!order || !isFinal(order.status)) load(); }, 2000);
    return () => { alive = false; clearInterval(t); };
  }, [id, order?.status]);

  if (error) return <main className="card narrow"><p className="err">{error}</p></main>;
  if (!order) return <main className="card narrow">Loading…</main>;

  if (order.status === 'paid' || order.status === 'paid_late') {
    return (
      <main className="card narrow paid">
        <div className="tick">✓</div>
        <h1>Payment received</h1>
        <p>R{order.amountZar.toFixed(2)} to {order.label || 'the shop'}</p>
        {order.explorer && <a href={order.explorer} target="_blank" rel="noreferrer">View transaction</a>}
      </main>
    );
  }
  if (order.status !== 'open') {
    return <main className="card narrow"><h1>This request is {order.status}</h1></main>;
  }

  return (
    <main className="card narrow">
      <h2>Pay {order.id}</h2>
      <div className="big">{order.usdc} <small>USDC</small></div>
      <p className="note">≈ R{order.amountZar.toFixed(2)} · pay the exact amount</p>
      <a className="qr" href={order.paymentUri}><QRCodeSVG value={order.paymentUri} size={220} /></a>
      <a className="btn primary" href={order.paymentUri}>Open in wallet</a>
      <p className="note">Gas is sponsored by the shop in this demo. Only send the exact amount shown.</p>
    </main>
  );
}
