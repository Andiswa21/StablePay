import { useEffect, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { api, isFinal } from '../api.js';

// Shopkeeper's screen: create a payment request, show the QR, wait for PAID.
export default function Till() {
  const [amount, setAmount] = useState('85');
  const [label, setLabel] = useState('Bread, milk');
  const [order, setOrder] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  // Poll the order until it reaches a final state. Matching happens on the server.
  useEffect(() => {
    if (!order || isFinal(order.status)) return;
    const t = setInterval(async () => {
      try { setOrder(await api(`/orders/${order.id}`)); } catch (e) { setError(e.message); }
    }, 2000);
    return () => clearInterval(t);
  }, [order?.id, order?.status]);

  async function charge() {
    setBusy(true); setError('');
    try {
      setOrder(await api('/orders', { method: 'POST', body: { amountZar: Number(amount), label } }));
    } catch (e) { setError(e.message); } finally { setBusy(false); }
  }

  if (!order) {
    return (
      <main className="card narrow">
        <h1>New sale</h1>
        <label>Amount (ZAR)
          <input inputMode="decimal" value={amount} onChange={e => setAmount(e.target.value)} />
        </label>
        <label>Note
          <input value={label} onChange={e => setLabel(e.target.value)} />
        </label>
        <button className="btn primary" onClick={charge} disabled={busy}>Charge R{amount || 0}</button>
        {error && <p className="err">{error}</p>}
      </main>
    );
  }

  if (order.status === 'paid' || order.status === 'paid_late') {
    return (
      <main className="card narrow paid">
        <div className="tick">✓</div>
        <h1>PAID</h1>
        <div className="big">R{order.amountZar.toFixed(2)}</div>
        <p>{order.usdc} USDC · {order.id}</p>
        {order.status === 'paid_late' && <p className="warn">Paid after the rate lock. Check the rate before handing over goods.</p>}
        <p className="note">Hand over the goods. Matched automatically.</p>
        {order.explorer && <a href={order.explorer} target="_blank" rel="noreferrer">View transaction</a>}
        <button className="btn primary" onClick={() => setOrder(null)}>New sale</button>
      </main>
    );
  }

  if (order.status === 'expired') {
    return (
      <main className="card narrow">
        <h1>Request expired</h1>
        <p className="note">Nothing was paid to {order.id}. Start a new sale.</p>
        <button className="btn primary" onClick={() => setOrder(null)}>New sale</button>
      </main>
    );
  }

  if (order.status === 'refunded') {
    return (
      <main className="card narrow">
        <h1>Refunded</h1>
        <p className="note">{order.id} was refunded to the payer.</p>
        <button className="btn primary" onClick={() => setOrder(null)}>New sale</button>
      </main>
    );
  }

  const secsLeft = Math.max(0, Math.round((order.quoteExpiresAt - Date.now()) / 1000));
  return (
    <main className="card narrow">
      <div className="row"><span>{order.id}</span><span>Rate locked: {secsLeft}s</span></div>
      <div className="big">{order.usdc} <small>USDC</small></div>
      <p className="note">R{order.amountZar.toFixed(2)} at 1 USDC = R{order.rate}</p>
      <a className="qr" href={order.paymentUri} aria-label="Open payment request in wallet">
        <QRCodeSVG value={order.paymentUri} size={220} />
      </a>
      <p className="note">Customer scans with a wallet on Base Sepolia. Waiting for payment…</p>
      <button className="btn ghost" onClick={() => setOrder(null)}>Cancel sale</button>
    </main>
  );
}
