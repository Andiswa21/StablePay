import { NavLink, Navigate, Route, Routes } from 'react-router-dom';
import Till from './pages/Till.jsx';
import Pay from './pages/Pay.jsx';
import Operator from './pages/Operator.jsx';

export default function App() {
  return (
    <div className="shell">
      <header className="topbar">
        <strong>StablePay</strong>
        <nav>
          <NavLink to="/till">Till</NavLink>
          <NavLink to="/operator">Operator</NavLink>
        </nav>
        <span className="net">Base Sepolia · testnet</span>
      </header>
      <Routes>
        <Route path="/" element={<Navigate to="/till" replace />} />
        <Route path="/till" element={<Till />} />
        <Route path="/pay/:id" element={<Pay />} />
        <Route path="/operator" element={<Operator />} />
      </Routes>
    </div>
  );
}
