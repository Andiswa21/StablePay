# StablePay: merchant and machine payments on Base Sepolia

A working MVP for the Node Engine Hackathon merchant and machine tracks. A till creates a payment request
(QR or link, EIP-681), a customer pays in USDC from a wallet, the server matches the transfer to the order
automatically, and the operator sees what was paid, refunds, cashes out, and caps what machines can spend.

Everything runs on Base Sepolia testnet. No real funds are involved.

## Setup (in this order)

1. **Watch or skim the workshop slides** (Merchant & Machine Payments). The merchant checkout code is on the
   "Merchant checkout: request, then watch" slide. This project implements that flow in `server/watcher.js`
   and `server/orders.js`.

2. **Get test USDC** from https://faucet.circle.com, choose Base Sepolia, and send it to two addresses: the
   merchant wallet (`MERCHANT_KEY`) and the machine wallet (`CAR_KEY`). Also get Base Sepolia ETH for gas
   if the faucet asks for it. Create the keys with a wallet you use only for testing.

3. **Merchant path.** Install and configure:
   ```bash
   npm install
   cp .env.example .env     # fill in MERCHANT_KEY, OPERATOR_PIN, CHARGER_ADDRESS, CAR_KEY
   npm run dev             # API on :3001, web on :5173
   ```
   Open http://localhost:5173/till, enter R85, and scan the QR with a wallet on Base Sepolia (MiniPay,
   MetaMask or Coinbase Wallet set to Base Sepolia). The screen turns to PAID once the transfer is seen
   onchain. The watcher polls every 4 seconds.

4. **Machine path (x402).** The charger endpoint `POST /charge` sits behind an x402 paywall that asks for
   $0.25 per kWh on Base Sepolia. Pay it from a script:
   ```bash
   # Register the device first, from the operator page or with curl:
   curl -X POST localhost:3001/api/devices -H 'x-operator-pin: YOUR_PIN' -H 'content-type: application/json' \
     -d '{"deviceId":"CHG-12","wallet":"0xYOUR_CAR_ADDRESS","capUsdc":"5","windowHours":24}'
   npm run pay-machine     # expect: status 200 and {"kwh":1,...}
   ```
   Follow the x402 quickstart (docs.cdp.coinbase.com/x402) if an import path has changed; see "Known gaps".

5. **Operator path.** Open http://localhost:5173/operator, enter the PIN, and you get the orders table,
   unmatched transfers, cash-out, device caps with revoke, and refunds.

## The four questions

**1. How does the customer pay in seconds, from a phone they already own?**
The till shows a QR code that encodes an EIP-681 ERC-20 transfer: token, recipient and exact amount are
filled in. Any wallet that reads EIP-681 opens with the payment ready to confirm. The shop's NFC sticker
and a payment link can point to the same request (`/pay/:id`). The rate is locked for 60 seconds.
Gas sponsorship is a design target, not built here: in this MVP the customer pays a little Base Sepolia
ETH for gas. For mainnet pilots, use a paymaster or a gas-sponsoring wallet.

**2. How does the merchant know which order was paid, without a block explorer?**
Each open order gets a unique USDC amount (base amount plus a micro-unit offset, for example 4.863844 and
4.863845). The watcher reads USDC `Transfer` events to the merchant address and matches each transfer by
its exact amount to an open order. Matching is idempotent: each log is recorded by transaction hash and log
index, so a transfer is never counted twice. The till polls the order and shows PAID. Transfers that match
no order (wrong amount, too late, or stray) go to the operator's "Unmatched transfers" list.

**3. How does the money reach a bank, mobile money or the next supplier?**
Stablecoin balances stay in the merchant wallet until cash-out. The operator enters an amount, the server
checks it against settled sales minus earlier payouts, takes a 0.5% illustrative fee, and submits to an
off-ramp. In this MVP the off-ramp is a mock (`server/payouts.js`) so the flow and balance checks run
end to end. A real pilot needs a licensed partner that pays out to a bank account or mobile money (ZAR).
Supplier payments are the same pattern: a USDC transfer from the merchant wallet to the supplier address.

**4. If the payer is a machine, what's the most it can spend, and who can stop it?**
The cap is set by the operator, stored on the server, and changed only through the PIN-protected
`/api/devices` routes. The device has no way to change it. `deviceGate` checks the cap before the x402
paywall, so a capped or revoked device never gets a price to pay. `POST /api/devices/:id/revoke` is the
kill switch. The machine wallet should also hold only the budget the operator funds, as a second limit.

## Known gaps (be honest about these with judges)

- **Not yet tested end to end by the author.** The code follows the workshop slides and the x402 and viem
  APIs. Run the steps above and fix any import or version mismatch before the demo.
- **x402 import paths.** The slide shows `@x402/express` and `@x402/fetch` (v2) and `ExactEvmScheme`. The
  exact subpath for `ExactEvmScheme` (`@x402/evm/exact/server` and `@x402/evm/exact/client` here) and the
  facilitator class come from the quickstart. Match them to the installed package.
- **Device identity is not authenticated.** The device sends `X-Device-Id`. In production, the machine signs
  each request with a key registered by the operator, and the cap is tied to the payer address in the x402
  payment.
- **Cap race.** Spend is checked before the payment and recorded after it. Two simultaneous requests can
  both pass the check. Fix with a per-device lock or an atomic counter.
- **Rate is fixed.** `RATE_ZAR_PER_USDC` is a demo value. Use a live FX source with a short lock before pilots.
- **Storage is a JSON file.** Fine for a demo. Use Postgres before real volume.
- **Watcher start.** On first run it scans the last 50 blocks only, so older transfers are not matched.
- **Refunds** send USDC from the merchant wallet. Make sure the merchant wallet holds enough test USDC.

## Project layout

```
server/index.js        Express API, operator routes, x402 paywall on /charge
server/orders.js       payment requests, unique amounts, EIP-681 URI, expiry
server/watcher.js      automatic matching from USDC Transfer events
server/chain.js        viem clients, refunds
server/devices.js      machine spend caps and kill switch
server/payouts.js      cash-out balance checks and off-ramp mock
server/pay-machine.js  machine script that pays the x402 paywall
client/src/pages/      Till (shopkeeper), Pay (customer), Operator (owner)
GTM.md                 customer, pilot and go-to-market plan
```
