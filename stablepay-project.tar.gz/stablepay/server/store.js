// Small JSON file store. Fine for a hackathon pilot; swap for Postgres before real volume.
import fs from 'node:fs';
import path from 'node:path';

const FILE = path.resolve(process.cwd(), 'data/db.json');
const empty = () => ({ orders: {}, transfers: [], payouts: [], devices: {}, meta: { lastBlock: null, seq: 41 } });

function load() {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return empty(); }
}

export const db = load();

export function persist() {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(db, null, 2));
}
