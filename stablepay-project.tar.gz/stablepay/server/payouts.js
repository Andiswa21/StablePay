// Cash-out. Settlement to bank or mobile money goes through a licensed off-ramp partner.
// The provider call below is a mock so the flow and the balance checks can be tested end to end.
import { db, persist } from './store.js';

const FEE = 0.005;   // 0.5% illustrative fee. Replace with the partner's real fee schedule.

export const settledUsdc = () =>
  Object.values(db.orders).filter(o => ['paid', 'paid_late'].includes(o.status)).reduce((a, o) => a + Number(o.usdc), 0);

const paidOut = () => db.payouts.reduce((a, p) => a + p.usdc, 0);
export const available = () => +(settledUsdc() - paidOut()).toFixed(6);

export function createPayout(usdc) {
  if (!(usdc > 0)) throw new Error('amount must be greater than 0');
  if (usdc > available()) throw new Error(`only ${available()} USDC is available to cash out`);
  const id = `PO-${db.payouts.length + 1}`;
  const payout = {
    id, usdc,
    feeUsdc: +(usdc * FEE).toFixed(6),
    netUsdc: +(usdc * (1 - FEE)).toFixed(6),
    status: 'submitted_mock',
    reference: `MOCK-${id}`,          // real partner: store the partner's reference and poll its status
    at: Date.now()
  };
  db.payouts.push(payout);
  persist();
  return payout;
}

export const listPayouts = () => db.payouts;
