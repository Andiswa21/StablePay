import { createPublicClient, createWalletClient, http, erc20Abi } from 'viem';
import { baseSepolia } from 'viem/chains';
import { CFG, merchantAccount } from './config.js';
import { db, persist } from './store.js';

const transport = http(CFG.rpc);
export const publicClient = createPublicClient({ chain: baseSepolia, transport });
const walletClient = merchantAccount
  ? createWalletClient({ account: merchantAccount, chain: baseSepolia, transport })
  : null;

// Refund: the merchant sends the exact USDC back to the payer. Irreversible, so operator PIN only.
export async function refundOrder(id) {
  const o = db.orders[id];
  if (!o) throw new Error('order not found');
  if (!['paid', 'paid_late'].includes(o.status)) throw new Error('only paid orders can be refunded');
  if (!walletClient) throw new Error('MERCHANT_KEY is not set');
  const hash = await walletClient.writeContract({
    address: CFG.usdc, abi: erc20Abi, functionName: 'transfer',
    args: [o.payer, BigInt(o.amountMicro)]
  });
  await publicClient.waitForTransactionReceipt({ hash });
  o.refund = { txHash: hash, at: Date.now() };
  o.status = 'refunded';
  persist();
  return o;
}
