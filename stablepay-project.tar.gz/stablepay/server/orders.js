import { db, persist } from './store.js';
import { CFG, MERCHANT } from './config.js';

const toMicro = usdc => Math.round(usdc * 1e6);        // USDC has 6 decimals
const now = () => Date.now();

export function expireStale() {
  let changed = false;
  for (const o of Object.values(db.orders)) {
    if (o.status === 'open' && now() > o.holdUntil) { o.status = 'expired'; changed = true; }
  }
  if (changed) persist();
}

// Matching key: every open order gets a unique USDC amount, so an incoming transfer
// identifies its order by amount alone. Two R85 sales at once get 4.863844 and 4.863845.
export function createOrder({ amountZar, label }) {
  expireStale();
  const base = toMicro(amountZar / CFG.rateZarPerUsdc);
  const taken = new Set(Object.values(db.orders).filter(o => o.status === 'open').map(o => o.amountMicro));
  let amountMicro = base;
  while (taken.has(amountMicro)) amountMicro += 1;

  db.meta.seq += 1;
  const id = `SPZ-${String(db.meta.seq).padStart(3, '0')}`;
  const t = now();
  db.orders[id] = {
    id, label, amountZar, rate: CFG.rateZarPerUsdc,
    amountMicro, usdc: (amountMicro / 1e6).toFixed(6),
    status: 'open',
    createdAt: t,
    quoteExpiresAt: t + CFG.quoteSeconds * 1000,
    holdUntil: t + CFG.holdMinutes * 60 * 1000,
    payer: null, txHash: null, paidAt: null, refund: null
  };
  persist();
  return db.orders[id];
}

// EIP-681 request for an ERC-20 transfer: the wallet opens with token, recipient and exact amount filled in.
export const paymentUri = o =>
  `ethereum:${CFG.usdc}@${CFG.chainId}/transfer?address=${MERCHANT}&uint256=${o.amountMicro}`;

export function getOrder(id) { expireStale(); return db.orders[id]; }

export function listOrders() {
  expireStale();
  return Object.values(db.orders).sort((a, b) => b.createdAt - a.createdAt);
}

export const publicOrder = o => ({
  id: o.id, label: o.label, amountZar: o.amountZar, usdc: o.usdc, rate: o.rate,
  status: o.status, quoteExpiresAt: o.quoteExpiresAt, holdUntil: o.holdUntil,
  payer: o.payer, txHash: o.txHash, paidAt: o.paidAt, refund: o.refund,
  paymentUri: paymentUri(o),
  explorer: o.txHash ? `https://sepolia.basescan.org/tx/${o.txHash}` : null
});
