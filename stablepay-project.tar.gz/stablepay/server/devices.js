// Machine spend caps. The cap lives in the server database and is set only through the operator PIN.
// The device's own code has no endpoint that can change it.
import { db, persist } from './store.js';

const spentInWindow = d => {
  const cutoff = Date.now() - d.windowHours * 3600e3;
  return d.spends.filter(s => s.at >= cutoff).reduce((a, s) => a + s.usdc, 0);
};

export function registerDevice({ deviceId, wallet, capUsdc, windowHours = 24 }) {
  if (!deviceId || !/^0x[a-fA-F0-9]{40}$/.test(wallet || '')) throw new Error('deviceId and a 0x wallet address are required');
  const cap = Number(capUsdc);
  if (!(cap > 0)) throw new Error('capUsdc must be greater than 0');
  db.devices[deviceId] = { deviceId, wallet, capUsdc: cap, windowHours: Number(windowHours), revoked: false, spends: [] };
  persist();
  return db.devices[deviceId];
}

export const listDevices = () =>
  Object.values(db.devices).map(d => ({ ...d, spentInWindow: +spentInWindow(d).toFixed(6) }));

export function revokeDevice(id) {            // kill switch
  if (db.devices[id]) { db.devices[id].revoked = true; persist(); }
}

export function recordSpend(id, usdc) {
  db.devices[id].spends.push({ usdc, at: Date.now() });
  persist();
}

// Runs before the x402 paywall, so a revoked or capped device never gets a 402 to pay.
export const deviceGate = price => (req, res, next) => {
  const id = req.get('x-device-id');
  const d = id && db.devices[id];
  if (!d) return res.status(403).json({ error: 'unknown device' });
  if (d.revoked) return res.status(403).json({ error: 'device revoked by operator' });
  const spent = spentInWindow(d);
  if (spent + price > d.capUsdc) {
    return res.status(403).json({ error: `cap reached: ${spent.toFixed(2)} of ${d.capUsdc} USDC spent this window` });
  }
  req.deviceId = id;
  next();
};
