import express from 'express';
import { paymentMiddleware, x402ResourceServer, HTTPFacilitatorClient } from '@x402/express';
import { ExactEvmScheme } from '@x402/evm/exact/server';
import { CFG, MERCHANT } from './config.js';
import { db } from './store.js';
import { createOrder, getOrder, listOrders, publicOrder } from './orders.js';
import { startWatcher } from './watcher.js';
import { refundOrder } from './chain.js';
import { registerDevice, listDevices, revokeDevice, deviceGate, recordSpend } from './devices.js';
import { createPayout, listPayouts } from './payouts.js';

const app = express();
app.use(express.json());

// Operator routes need the PIN in a header. Refuse to run them if no PIN is configured.
const operator = (req, res, next) => {
  if (!CFG.operatorPin) return res.status(500).json({ error: 'OPERATOR_PIN is not set' });
  if (req.get('x-operator-pin') !== CFG.operatorPin) return res.status(401).json({ error: 'operator PIN required' });
  next();
};
const wrap = fn => (req, res) => Promise.resolve(fn(req, res)).catch(e => res.status(400).json({ error: e.message }));

app.get('/api/health', (_, res) => res.json({ ok: true, merchant: MERCHANT, network: 'base-sepolia' }));

// ---- Merchant path: payment request, customer status ----
app.post('/api/orders', wrap((req, res) => {
  const amountZar = Number(req.body?.amountZar);
  if (!(amountZar > 0)) throw new Error('amountZar must be greater than 0');
  res.status(201).json(publicOrder(createOrder({ amountZar, label: String(req.body.label || '') })));
}));

app.get('/api/orders/:id', (req, res) => {
  const o = getOrder(req.params.id);
  if (!o) return res.status(404).json({ error: 'order not found' });
  res.json(publicOrder(o));
});

// ---- Operator view ----
app.get('/api/orders', operator, (_, res) => res.json(listOrders().map(publicOrder)));
app.post('/api/orders/:id/refund', operator, wrap(async (req, res) => res.json(publicOrder(await refundOrder(req.params.id)))));
app.get('/api/transfers', operator, (_, res) => res.json(db.transfers.filter(t => t.unmatched)));

// ---- Machine caps ----
app.get('/api/devices', operator, (_, res) => res.json(listDevices()));
app.post('/api/devices', operator, wrap((req, res) => res.status(201).json(registerDevice(req.body))));
app.post('/api/devices/:id/revoke', operator, (req, res) => { revokeDevice(req.params.id); res.json({ ok: true }); });

// ---- Cash-out ----
app.get('/api/payouts', operator, (_, res) => res.json(listPayouts()));
app.post('/api/payouts', operator, wrap((req, res) => res.status(201).json(createPayout(Number(req.body?.amountUsdc)))));

// ---- Machine path: x402 paywall on a per-kWh charge ----
const x402Server = new x402ResourceServer(new HTTPFacilitatorClient({ url: 'https://x402.org/facilitator' }))
  .register('eip155:84532', new ExactEvmScheme());

app.post('/charge',
  deviceGate(CFG.pricePerKwhUsdc),
  paymentMiddleware({
    'POST /charge': {
      accepts: [{ scheme: 'exact', price: CFG.pricePerKwhUsd, network: 'eip155:84532', payTo: CFG.charger }],
      description: '1 kWh of EV charging'
    }
  }, x402Server),
  (req, res) => {
    recordSpend(req.deviceId, CFG.pricePerKwhUsdc);
    console.log(`[charger] ${req.deviceId} charging 1 kWh`);
    res.json({ kwh: 1, device: req.deviceId });
  });

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`API on http://localhost:${PORT}  merchant ${MERCHANT || '(MERCHANT_KEY not set)'}`);
  if (!CFG.charger) console.warn('CHARGER_ADDRESS not set: /charge will fail');
  startWatcher();
});
