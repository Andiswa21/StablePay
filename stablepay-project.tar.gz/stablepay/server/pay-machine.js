// Machine path: a device with a testnet wallet pays the x402 paywall and gets its 200 OK.
import 'dotenv/config';
import { privateKeyToAccount } from 'viem/accounts';
import { wrapFetchWithPaymentFromConfig } from '@x402/fetch';
import { ExactEvmScheme } from '@x402/evm/exact/client';

if (!process.env.CAR_KEY) throw new Error('Set CAR_KEY to a Base Sepolia test key');
const account = privateKeyToAccount(process.env.CAR_KEY);

const pay = wrapFetchWithPaymentFromConfig(fetch, {
  schemes: [{ network: 'eip155:84532', client: new ExactEvmScheme(account) }]
});

const url = process.env.CHARGER_URL || 'http://localhost:3001/charge';
const res = await pay(url, {
  method: 'POST',
  headers: { 'X-Device-Id': process.env.DEVICE_ID || 'CHG-12' }
});
console.log('status', res.status);
console.log(await res.text());
