// Automatic matching. Polls USDC Transfer events to the merchant address and ties each one to an order.
// Nobody checks a block explorer by hand.
import { erc20Abi } from 'viem';
import { CFG, MERCHANT } from './config.js';
import { db, persist } from './store.js';
import { publicClient } from './chain.js';

export async function pollOnce() {
  const latest = await publicClient.getBlockNumber();
  const from = db.meta.lastBlock == null ? latest - 50n : BigInt(db.meta.lastBlock) + 1n;
  if (from > latest) return;

  const logs = await publicClient.getContractEvents({
    address: CFG.usdc, abi: erc20Abi, eventName: 'Transfer',
    args: { to: MERCHANT }, fromBlock: from, toBlock: latest
  });
  for (const log of logs) match(log);

  db.meta.lastBlock = Number(latest);
  persist();
}

function match(log) {
  const key = `${log.transactionHash}:${log.logIndex}`;
  if (db.transfers.some(t => t.key === key)) return;       // never count a transfer twice

  const value = Number(log.args.value);
  const at = Date.now();
  const order = Object.values(db.orders).find(o => o.status === 'open' && o.amountMicro === value);
  const base = { key, amountMicro: value, payer: log.args.from, txHash: log.transactionHash, at };

  if (!order) { db.transfers.push({ ...base, unmatched: true }); return; }   // wrong amount, late, or stray

  order.status = at <= order.quoteExpiresAt ? 'paid' : 'paid_late';
  order.payer = log.args.from;
  order.txHash = log.transactionHash;
  order.paidAt = at;
  db.transfers.push({ ...base, matchedOrderId: order.id });
}

export function startWatcher() {
  return setInterval(() => {
    pollOnce().catch(e => console.error('[watcher]', e.shortMessage || e.message));
  }, 4000);
}
