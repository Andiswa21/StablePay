import 'dotenv/config';
import { privateKeyToAccount } from 'viem/accounts';

export const merchantAccount = process.env.MERCHANT_KEY
  ? privateKeyToAccount(process.env.MERCHANT_KEY)
  : null;

export const MERCHANT = merchantAccount?.address;

export const CFG = {
  rpc: process.env.BASE_SEPOLIA_RPC || 'https://sepolia.base.org',
  chainId: 84532,                                             // Base Sepolia
  usdc: '0x036CbD53842c5426634e7929541eC2318f3dCF7e',         // USDC on Base Sepolia (6 decimals)
  rateZarPerUsdc: Number(process.env.RATE_ZAR_PER_USDC || 17.48),
  quoteSeconds: 60,                                           // rate lock
  holdMinutes: 15,                                            // how long an open order can still be matched
  operatorPin: process.env.OPERATOR_PIN,
  charger: process.env.CHARGER_ADDRESS,
  pricePerKwhUsd: '$0.25',                                    // x402 price string
  pricePerKwhUsdc: 0.25                                       // same price, as a number for spend caps
};
